## Example config file
##```python

# Your Telegram bot token.
BOT_TOKEN = "7881707295:AAEfA9_Vy3JGpEcX69muN6qEbkvp7jt6WBc"

# Telegram API ID and Hash. This is NOT your bot token and shouldn't be changed.
API_ID = 9641313
API_HASH = "baefb797b70643121704c7f344b92870"

# Chat used for logging errors.
LOG_CHAT = 6254163794

# Chat used for logging user actions (like buy, gift, etc).
ADMIN_CHAT = 6254163794
GRUPO_PUB = -1002412340501


# How many updates can be handled in parallel.
# Don't use high values for low-end servers.
WORKERS = 20

# Admins can access panel and add new materials to the bot.
ADMINS = [6254163794]

# Sudoers have full access to the server and can execute commands.
SUDOERS = [6254163794]

# All sudoers should be admins too
ADMINS.extend(SUDOERS)

GIFTERS = [6254163794]

# Bote o Username do bot sem o @
# Exemplo: default
BOT_LINK = "testephdbot"



# Bote o Username do suporte sem o @
# Exemplo: suporte
BOT_LINK_SUPORTE = "testephdbot"
##```
