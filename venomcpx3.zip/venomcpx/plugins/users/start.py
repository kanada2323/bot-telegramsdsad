from typing import Union

from pyrogram import Client, filters
from pyrogram.errors import BadRequest
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from database import cur, save
from utils import create_mention, get_info_wallet

@Client.on_message(filters.command(["start", "menu"]))
@Client.on_callback_query(filters.regex("^start$"))
async def start(c: Client, m: Union[Message, CallbackQuery]):
    user_id = m.from_user.id
       
    try:
        chat_member = await c.get_chat_member("-1001843160970", m.from_user.id)
        status = chat_member.status
    except Exception as e:
        #print(f"Erro ao verificar a associação ao canal: {e}")
        status = None

    if status is None:
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                 [
                 InlineKeyboardButton("Entre", url="https://t.me/refdovenom")
                 ],
            ]
        )
        return await c.send_message(m.from_user.id, "Para acessar este bot é obrigatório que se inscreva no canal abaixo!\n\nInscreva-se agora clicando abaixo para poder começar a usar o bot:", reply_markup=kb)
    else:
        rt = cur.execute(
            "SELECT id, balance, balance_diamonds, refer FROM users WHERE id=?", [user_id]
        ).fetchone()

        if isinstance(m, Message):
            refer = (
                int(m.command[1])
                if (len(m.command) == 2)
                and (m.command[1]).isdigit()
                and int(m.command[1]) != user_id
                else None
            )
            
            if rt[3] is None:
                if refer is not None:
                    mention = create_mention(m.from_user, with_id=False)

                    cur.execute("UPDATE users SET refer = ? WHERE id = ?", [refer, user_id])
                    try:
                        await c.send_message(
                            refer,
                            text=f"🎁 <b>Parabéns, o usuário {mention} se vinculou com seu link de afiliado e você receberá uma porcentagem do que o mesmo adicionar no nosso bot.</b>",
                        )
                    except BadRequest:
                        pass

        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton("🛒 Comprar ", callback_data="comprar"),
                 InlineKeyboardButton("💵 Adicionar Saldo", callback_data="add_saldo_manual")],
                [InlineKeyboardButton("👤 perfil", callback_data="user_info"),
                 InlineKeyboardButton("🏆 ranking", callback_data="ranking")],
            ]
        )

        bot_logo, news_channel, support_user = cur.execute(
            "SELECT main_img, channel_user, support_user FROM bot_config WHERE ROWID = 0"
        ).fetchone()

        start_message = f"""‌<b>🛒 Olá</b> <code>{m.from_user.first_name}</code><b>, Seja bem vindo a store</b>

<b>💸 Recarga rápida:</b>
Precisa recarregar? É simples! Use o comando <code>/pix</code> (valor) e pronto. Rápido e fácil.

    <b>🔑 Termos Importantes:</b>
    <i>📌 Não garantimos saldo ou aprovação
    📌 Garantimos que a GG/CC esteja live!
    📌 Garantimos Todos logins lives</i>

{get_info_wallet(m.from_user.id)}"""

        if isinstance(m, CallbackQuery):
            send = m.edit_message_text
        else:
            send = m.reply_text
        save()
        await send(start_message, reply_markup=kb)
