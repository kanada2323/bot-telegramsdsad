from typing import Union

from pyrogram import Client, filters
from pyrogram.errors import BadRequest
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from database import cur, save
from utils import create_mention, get_info_wallet

image_url = "https://i.imgur.com/05S3JFl.jpg"

@Client.on_callback_query(filters.regex(r"^comprar$"))
async def comprar(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("💳 Comprar FULL", callback_data="comprar_full")
            ],
            [
                InlineKeyboardButton("💳 Comprar Geradas", callback_data="comprar_gg")
            ],
            [
           InlineKeyboardButton("🎟️ Comprar Logins", callback_data="comprar_login unit")
            ],
            [
                InlineKeyboardButton("❮ ❮", callback_data="start"),
            ],
        ]
    )

    await m.edit_message_text(

        f"""<a href="{image_url}">&#8205;</a><b>🛒 Escolha a categoria de produto e comece suas compras!</b>""",
  reply_markup=kb,
    )
    